import threading
import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
from urllib.parse import urljoin, urlparse
import phonenumbers
from concurrent.futures import ThreadPoolExecutor, as_completed
from flask import Flask, render_template, request, jsonify, send_file
import os
import uuid

app = Flask(__name__)

# Ensure downloads directory exists
DOWNLOADS_DIR = "downloads"
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

class Scraper:
    def __init__(self):
        self.results = []
        self.stop_flag = False
        self.stats = {"detected": 0, "successful": 0, "unsuccessful": 0, "phones_found": 0, "phones_not_found": 0}
        self.progress = "Ready"
        self.lock = threading.Lock()

    def reset(self):
        with self.lock:
            self.results.clear()
            self.stop_flag = False
            self.stats = {"detected": 0, "successful": 0, "unsuccessful": 0, "phones_found": 0, "phones_not_found": 0}
            self.progress = "Ready"

    def scrape_urls(self, raw_data, session_id):
        self.progress = "Detecting URLs..."
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', raw_data)
        self.stats["detected"] = len(urls)

        if not urls:
            self.progress = "No URLs found!"
            return

        total_urls = len(urls)
        processed = 0
        max_workers = min(10, max(1, threading.active_count() + 1))

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_url = {executor.submit(self.scrape_website, url): url for url in urls}
            for future in as_completed(future_to_url):
                if self.stop_flag:
                    break
                processed += 1
                url = future_to_url[future]
                self.progress = f"Scraping {processed}/{total_urls} ({processed/total_urls*100:.1f}%): {url}"
                try:
                    data = future.result()
                    if data and data["phone"]:
                        with self.lock:
                            self.results.append(data)
                            self.stats["successful"] += 1
                            self.stats["phones_found"] += 1
                    else:
                        with self.lock:
                            self.stats["unsuccessful"] += 1
                            self.stats["phones_not_found"] += 1
                except Exception as e:
                    with self.lock:
                        self.stats["unsuccessful"] += 1
                        self.stats["phones_not_found"] += 1
                    print(f"Error scraping {url}: {e}")

        self.progress = "Scraping Complete!" if not self.stop_flag else "Scraping Stopped!"

    def scrape_website(self, url):
        if self.stop_flag:
            return None
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            home_soup = BeautifulSoup(response.text, 'html.parser')

            data = {
                "name": self.extract_domain_name(url),
                "url": url,
                "country": "",
                "email": "",
                "phone": "",
                "instagram": "",
                "facebook": ""
            }

            # Step 1: Determine country intelligently
            data["country"] = self.extract_country(url, home_soup)

            # Step 2: Exhaustive phone number search
            data["phone"] = self.extract_intelligent_phone(home_soup, data["country"])
            if not data["phone"]:
                for page in self.find_relevant_pages(url, home_soup):
                    try:
                        page_response = requests.get(page, headers=headers, timeout=10)
                        page_soup = BeautifulSoup(page_response.text, 'html.parser')
                        data["phone"] = self.extract_intelligent_phone(page_soup, data["country"])
                        if data["phone"]:
                            break
                    except:
                        continue
            if not data["phone"]:
                return None  # Skip if no phone found

            # Step 3: Exhaustive email search
            contact_soup = BeautifulSoup(requests.get(self.find_contact_page(url, home_soup) or url, headers=headers, timeout=10).text, 'html.parser')
            data["email"] = self.extract_intelligent_email(home_soup, contact_soup)
            if not data["email"]:
                for page in self.find_relevant_pages(url, home_soup):
                    try:
                        page_response = requests.get(page, headers=headers, timeout=10)
                        page_soup = BeautifulSoup(page_response.text, 'html.parser')
                        data["email"] = self.extract_intelligent_email(home_soup, page_soup)
                        if data["email"]:
                            break
                    except:
                        continue

            # Step 4: Extract social media links
            social_links = self.extract_social_links(url, home_soup, contact_soup)
            data["instagram"] = social_links["instagram"]
            data["facebook"] = social_links["facebook"]

            return data

        except Exception as e:
            print(f"Error scraping {url}: {e}")
            return None

    def extract_domain_name(self, url):
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        domain = re.sub(r'^www\.', '', domain)
        domain = re.sub(r'\..*', '', domain)
        return domain

    def find_relevant_pages(self, base_url, soup):
        keywords = ["contact", "about", "support", "call-us", "get-in-touch", "team", "directory", "help", "info", "staff", "faculty", "location"]
        pages = []
        for a in soup.find_all("a", href=True):
            href = a["href"].lower()
            if any(keyword in href for keyword in keywords) and not href.startswith("mailto:"):
                full_url = urljoin(base_url, href)
                if full_url not in pages and len(pages) < 5:
                    pages.append(full_url)
        return pages

    def find_contact_page(self, base_url, soup):
        for a in soup.find_all("a", href=True):
            href = a["href"].lower()
            if "contact" in href or "call" in href or "email" in href:
                return urljoin(base_url, href)
        return None

    def extract_intelligent_phone(self, soup, country):
        for a in soup.find_all("a", href=True):
            href = a["href"].lower()
            if href.startswith("tel:"):
                phone = href.replace("tel:", "").replace(" ", "").replace("-", "").replace(".", "")
                try:
                    parsed_phone = phonenumbers.parse(phone, self.country_to_region(country))
                    if phonenumbers.is_valid_number(parsed_phone):
                        return self.format_phone_number(parsed_phone, country)
                except phonenumbers.phonenumberutil.NumberParseException:
                    continue

        text = soup.get_text(separator=" ").lower() + " ".join([script.get_text() for script in soup.find_all("script") if script.get_text()])
        phone_patterns = [
            r'(\+\d{1,3}\s?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,5}',
            r'\d{2,4}-\d{3,4}-\d{3,5}',
            r'\d{8,12}',
            r'\d{2,4}\s\d{3,4}\s\d{3,5}'
        ]

        scored_phones = []
        region = self.country_to_region(country)
        for pattern in phone_patterns:
            candidates = re.findall(pattern, text)
            for phone in candidates:
                try:
                    parsed_phone = phonenumbers.parse(phone, region)
                    if not phonenumbers.is_valid_number(parsed_phone):
                        continue
                    formatted_phone = self.format_phone_number(parsed_phone, country)
                    score = 0
                    context = text[max(0, text.index(phone) - 150):text.index(phone) + 150]
                    if any(keyword in context for keyword in ["contact", "call", "phone", "tel", "reach", "support", "emergency", "hotline"]):
                        score += 40
                    if any(keyword in context for keyword in ["footer", "header", "team", "directory", "staff"]):
                        score += 20
                    if "toll" in context or "free" in context or "24/7" in context:
                        score += 15
                    scored_phones.append((formatted_phone, score))
                except phonenumbers.phonenumberutil.NumberParseException:
                    continue

        if scored_phones:
            best_phone, _ = max(scored_phones, key=lambda x: x[1])
            parsed_best = phonenumbers.parse(best_phone)
            country_code = str(parsed_best.country_code)
            expected_country = self.region_to_country(region)
            if country_code in phonenumbers.COUNTRY_CODE_TO_REGION_CODE and expected_country in phonenumbers.COUNTRY_CODE_TO_REGION_CODE[int(country_code)]:
                return best_phone
            else:
                for phone, score in scored_phones:
                    try:
                        parsed_phone = phonenumbers.parse(phone, None)
                        if phonenumbers.is_valid_number(parsed_phone):
                            return self.format_phone_number(parsed_phone, self.extract_country_from_phone(phone))
                    except:
                        continue
        return ""

    def format_phone_number(self, parsed_phone, country):
        country_code = phonenumbers.format_number(parsed_phone, phonenumbers.PhoneNumberFormat.INTERNATIONAL).split(" ")[0]
        national_number = phonenumbers.format_number(parsed_phone, phonenumbers.PhoneNumberFormat.NATIONAL).replace(" ", "").replace("-", "")
        
        if country == "Australia" and len(national_number) == 9:
            return f"{country_code}{national_number}"
        elif country in ["USA", "Canada"] and len(national_number) == 10:
            return f"{country_code}{national_number}"
        return phonenumbers.format_number(parsed_phone, phonenumbers.PhoneNumberFormat.E164)

    def extract_intelligent_email(self, home_soup, contact_soup):
        soups = [contact_soup, home_soup]
        for soup in soups:
            for a in soup.find_all("a", href=True):
                href = a["href"].lower()
                if href.startswith("mailto:"):
                    email = href.replace("mailto:", "").split("?")[0]
                    if re.match(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', email):
                        return email

        for soup in soups:
            text = soup.get_text().lower() + " ".join([script.get_text() for script in soup.find_all("script") if script.get_text()])
            emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
            encoded_emails = re.findall(r'[\w\.-]+(?:\s*\[at\]\s*|\s*@\s*|\s*at\s*)[\w\.-]+\.(?:com|org|net|edu|gov|[a-z]{2})', text)
            if emails:
                for email in emails:
                    if any(keyword in email.lower() for keyword in ["info", "contact", "support", "hello", "sales", "enquiries", "admin"]):
                        return email
                return emails[0]
            if encoded_emails:
                return encoded_emails[0].replace("[at]", "@").replace(" at ", "@").replace(" ", "")

        return ""

    def extract_social_links(self, base_url, home_soup, contact_soup):
        social_links = {"instagram": "", "facebook": ""}
        soups = [home_soup, contact_soup]
        
        for soup in soups:
            for a in soup.find_all("a", href=True):
                href = a["href"].lower()
                if "instagram.com" in href and not social_links["instagram"]:
                    handle = self.extract_social_handle(href, "instagram.com")
                    if handle:
                        social_links["instagram"] = f"@{handle}"
                if "facebook.com" in href and not social_links["facebook"]:
                    handle = self.extract_social_handle(href, "facebook.com")
                    if handle:
                        social_links["facebook"] = f"@{handle}"
                if social_links["instagram"] and social_links["facebook"]:
                    break

        if not (social_links["instagram"] or social_links["facebook"]):
            for page in self.find_relevant_pages(base_url, home_soup):
                try:
                    page_response = requests.get(page, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
                    page_soup = BeautifulSoup(page_response.text, 'html.parser')
                    for a in page_soup.find_all("a", href=True):
                        href = a["href"].lower()
                        if "instagram.com" in href and not social_links["instagram"]:
                            handle = self.extract_social_handle(href, "instagram.com")
                            if handle:
                                social_links["instagram"] = f"@{handle}"
                        if "facebook.com" in href and not social_links["facebook"]:
                            handle = self.extract_social_handle(href, "facebook.com")
                            if handle:
                                social_links["facebook"] = f"@{handle}"
                        if social_links["instagram"] and social_links["facebook"]:
                            break
                    if social_links["instagram"] and social_links["facebook"]:
                        break
                except:
                    continue

        return social_links

    def extract_social_handle(self, url, domain):
        parsed_url = urlparse(url)
        if domain not in parsed_url.netloc.lower():
            return ""
        path = parsed_url.path.strip('/')
        if not path or path in ["", "home", "index"]:
            return ""
        handle = path.split('/')[0].split('?')[0].split('#')[0]
        return handle if handle else ""

    def extract_country(self, url, soup):
        COUNTRY_CODE_MAP = {
            "1": "USA",
            "52": "Mexico",
            "55": "Brazil",
            "54": "Argentina",
            "34": "Spain",
            "33": "France",
            "352": "Luxembourg",
            "351": "Portugal",
            "44": "UK",
            "353": "Ireland",
            "39": "Italy",
            "46": "Sweden",
            "45": "Denmark",
            "20": "Egypt",
            "27": "South Africa",
            "966": "Saudi Arabia",
            "967": "Yemen",
            "968": "Oman",
            "971": "UAE",
            "973": "Bahrain",
            "974": "Qatar",
            "965": "Kuwait",
            "90": "Turkey",
            "98": "Iran",
            "86": "China",
            "7": "Russia",
            "61": "Australia",
            "64": "New Zealand",
            "63": "Philippines",
            "82": "South Korea",
            "81": "Japan"
        }

        TLD_COUNTRY_MAP = {
            "au": "Australia",
            "ca": "Canada",
            "cn": "China",
            "jp": "Japan",
            "uk": "UK",
            "kr": "South Korea",
            "nz": "New Zealand",
            "ph": "Philippines",
            "ru": "Russia",
            "tr": "Turkey",
            "eg": "Egypt",
            "za": "South Africa",
            "sa": "Saudi Arabia",
            "ir": "Iran",
            "ae": "UAE",
            "qa": "Qatar",
            "kw": "Kuwait",
            "bh": "Bahrain",
            "om": "Oman",
            "ye": "Yemen",
            "dk": "Denmark",
            "se": "Sweden",
            "it": "Italy",
            "ie": "Ireland",
            "pt": "Portugal",
            "lu": "Luxembourg",
            "es": "Spain",
            "fr": "France",
            "mx": "Mexico",
            "br": "Brazil",
            "ar": "Argentina"
        }

        text = soup.get_text(separator=" ").lower()
        countries = [
            "usa", "united states", "canada", "mexico", "brazil", "argentina", "spain", "france", "luxembourg", 
            "portugal", "uk", "united kingdom", "ireland", "italy", "sweden", "denmark", "egypt", "south africa", 
            "saudi arabia", "yemen", "oman", "uae", "united arab emirates", "bahrain", "qatar", "kuwait", 
            "turkey", "iran", "china", "russia", "australia", "new zealand", "philippines", "south korea", "japan"
        ]
        for country in countries:
            if country in text or country.replace(" ", "") in text:
                return country.title() if country not in ["usa", "uk", "uae"] else country.upper()

        tld = urlparse(url).netloc.split('.')[-1].lower()
        if tld in TLD_COUNTRY_MAP:
            return TLD_COUNTRY_MAP[tld].title() if TLD_COUNTRY_MAP[tld] not in ["USA", "UK", "UAE"] else TLD_COUNTRY_MAP[tld]

        phone = self.extract_intelligent_phone(soup, "Unknown")
        if phone:
            try:
                parsed_phone = phonenumbers.parse(phone, None)
                country_code = str(parsed_phone.country_code)
                return COUNTRY_CODE_MAP.get(country_code, "Unknown")
            except phonenumbers.phonenumberutil.NumberParseException:
                pass

        return "Unknown"

    def extract_country_from_phone(self, phone):
        COUNTRY_CODE_MAP = {
            "1": "USA",
            "52": "Mexico",
            "55": "Brazil",
            "54": "Argentina",
            "34": "Spain",
            "33": "France",
            "352": "Luxembourg",
            "351": "Portugal",
            "44": "UK",
            "353": "Ireland",
            "39": "Italy",
            "46": "Sweden",
            "45": "Denmark",
            "20": "Egypt",
            "27": "South Africa",
            "966": "Saudi Arabia",
            "967": "Yemen",
            "968": "Oman",
            "971": "UAE",
            "973": "Bahrain",
            "974": "Qatar",
            "965": "Kuwait",
            "90": "Turkey",
            "98": "Iran",
            "86": "China",
            "7": "Russia",
            "61": "Australia",
            "64": "New Zealand",
            "63": "Philippines",
            "82": "South Korea",
            "81": "Japan"
        }
        try:
            parsed_phone = phonenumbers.parse(phone, None)
            country_code = str(parsed_phone.country_code)
            return COUNTRY_CODE_MAP.get(country_code, "Unknown")
        except phonenumbers.phonenumberutil.NumberParseException:
            return "Unknown"

    def country_to_region(self, country):
        region_map = {
            "USA": "US",
            "Canada": "CA",
            "Mexico": "MX",
            "Brazil": "BR",
            "Argentina": "AR",
            "Spain": "ES",
            "France": "FR",
            "Luxembourg": "LU",
            "Portugal": "PT",
            "UK": "GB",
            "Ireland": "IE",
            "Italy": "IT",
            "Sweden": "SE",
            "Denmark": "DK",
            "Egypt": "EG",
            "South Africa": "ZA",
            "Saudi Arabia": "SA",
            "Yemen": "YE",
            "Oman": "OM",
            "UAE": "AE",
            "Bahrain": "BH",
            "Qatar": "QA",
            "Kuwait": "KW",
            "Turkey": "TR",
            "Iran": "IR",
            "China": "CN",
            "Russia": "RU",
            "Australia": "AU",
            "New Zealand": "NZ",
            "Philippines": "PH",
            "South Korea": "KR",
            "Japan": "JP"
        }
        return region_map.get(country, "US")

    def region_to_country(self, region):
        region_map = {
            "US": "USA",
            "CA": "Canada",
            "MX": "Mexico",
            "BR": "Brazil",
            "AR": "Argentina",
            "ES": "Spain",
            "FR": "France",
            "LU": "Luxembourg",
            "PT": "Portugal",
            "GB": "UK",
            "IE": "Ireland",
            "IT": "Italy",
            "SE": "Sweden",
            "DK": "Denmark",
            "EG": "Egypt",
            "ZA": "South Africa",
            "SA": "Saudi Arabia",
            "YE": "Yemen",
            "OM": "Oman",
            "AE": "UAE",
            "BH": "Bahrain",
            "QA": "Qatar",
            "KW": "Kuwait",
            "TR": "Turkey",
            "IR": "Iran",
            "CN": "China",
            "RU": "Russia",
            "AU": "Australia",
            "NZ": "New Zealand",
            "PH": "Philippines",
            "KR": "South Korea",
            "JP": "Japan"
        }
        return region_map.get(region, "Unknown")

    def export_to_excel(self, session_id):
        if not self.results:
            return None
        df = pd.DataFrame(self.results)
        file_path = os.path.join(DOWNLOADS_DIR, f"scraped_data_{session_id}.xlsx")
        df.to_excel(file_path, index=False)
        return file_path

# Global scraper instances per session
scrapers = {}

@app.route('/')
def index():
    session_id = str(uuid.uuid4())
    scrapers[session_id] = Scraper()
    return render_template('index.html', session_id=session_id, results=[], report="", progress="Ready")

@app.route('/start_scraping', methods=['POST'])
def start_scraping():
    session_id = request.form.get('session_id')
    if session_id not in scrapers:
        return jsonify({"error": "Invalid session", "progress": "Error", "results": [], "report": ""})

    scraper = scrapers[session_id]
    scraper.reset()
    raw_data = request.form.get('urls', '').strip()
    threading.Thread(target=scraper.scrape_urls, args=(raw_data, session_id), daemon=True).start()
    return jsonify({"progress": scraper.progress, "results": scraper.results, "report": ""})

@app.route('/stop_scraping', methods=['POST'])
def stop_scraping():
    session_id = request.form.get('session_id')
    if session_id not in scrapers:
        return jsonify({"error": "Invalid session", "progress": "Error", "results": [], "report": ""})

    scraper = scrapers[session_id]
    scraper.stop_flag = True
    scraper.progress = "Stopping..."
    return jsonify({"progress": scraper.progress, "results": scraper.results, "report": ""})

@app.route('/get_status', methods=['POST'])
def get_status():
    session_id = request.form.get('session_id')
    if session_id not in scrapers:
        return jsonify({"error": "Invalid session", "progress": "Error", "results": [], "report": ""})

    scraper = scrapers[session_id]
    report = (
        f"URLs Detected: {scraper.stats['detected']}\n"
        f"Successfully Scraped: {scraper.stats['successful']}\n"
        f"Unsuccessful Scrapes: {scraper.stats['unsuccessful']}\n"
        f"Phone Numbers Found: {scraper.stats['phones_found']}\n"
        f"Phone Numbers Not Found: {scraper.stats['phones_not_found']}"
    )
    return jsonify({"progress": scraper.progress, "results": scraper.results, "report": report})

@app.route('/export_excel/<session_id>')
def export_excel(session_id):
    if session_id not in scrapers:
        return jsonify({"error": "Invalid session"}), 400

    scraper = scrapers[session_id]
    file_path = scraper.export_to_excel(session_id)
    if not file_path:
        return jsonify({"error": "No data to export"}), 400
    return send_file(file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)