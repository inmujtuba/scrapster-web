function startScraping() {
    const form = document.getElementById('scrapeForm');
    const formData = new FormData(form);
    const stopButton = document.getElementById('stopButton');
    
    stopButton.disabled = false;
    fetch('/start_scraping', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('progress').textContent = data.progress;
        updateResults(data.results, data.report);
        pollStatus(formData.get('session_id'));
    });
}

function stopScraping() {
    const sessionId = document.getElementById('scrapeForm').querySelector('input[name="session_id"]').value;
    fetch('/stop_scraping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `session_id=${sessionId}`
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('progress').textContent = data.progress;
        document.getElementById('stopButton').disabled = true;
        updateResults(data.results, data.report);
    });
}

function pollStatus(sessionId) {
    fetch('/get_status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `session_id=${sessionId}`
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('progress').textContent = data.progress;
        updateResults(data.results, data.report);
        if (!data.progress.includes('Complete') && !data.progress.includes('Stopped') && !data.progress.includes('Error')) {
            setTimeout(() => pollStatus(sessionId), 1000);
        } else {
            document.getElementById('stopButton').disabled = true;
        }
    });
}

function updateResults(results, report) {
    const tbody = document.getElementById('resultsTable');
    tbody.innerHTML = '';
    results.forEach(result => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${result.name}</td>
            <td>${result.url}</td>
            <td>${result.country}</td>
            <td>${result.email}</td>
            <td>${result.phone}</td>
            <td>${result.instagram}</td>
            <td>${result.facebook}</td>
        `;
        tbody.appendChild(row);
    });
    document.getElementById('report').textContent = report;
}

function exportExcel(sessionId) {
    window.location.href = `/export_excel/${sessionId}`;
}